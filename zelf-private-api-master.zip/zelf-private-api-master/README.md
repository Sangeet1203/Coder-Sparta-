# Zelf Private Api
[![License: GPL v3](https://img.shields.io/badge/License-GPL%20v3-blue.svg)](http://www.gnu.org/licenses/gpl-3.0)
![](https://komarev.com/ghpvc/?username=ghrlt-zelf-private-api&color=brightgreen&label=Repository%20views)  

Private API for Zelf neobank


Made with the help of [HTTP Toolkit](https://github.com/httptoolkit/httptoolkit) for traffic sniffing.  
The repo will be updated as the app provides more functionnality


## Installation

	> git clone https://github.com/ghrlt/zelf-private-api
	> cd zelf-private-api
	> pip3 install -r requirements.txt


## Usage

	> python3 app.py


